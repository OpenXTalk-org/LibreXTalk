# xtalk-rs, step 1: a REPL

A tiny headless xTalk interpreter and a command-line prompt.

    cargo run -p xt-cli      # start the prompt
    cargo test               # run the unit tests

Inside the prompt, type `:help`.

Layout:

- `crates/xt-core`: lexer, parser, interpreter (no I/O of its own)
- `crates/xt-cli`: the `xt` prompt, which supplies a `Host` that prints to the terminal

License: MIT OR Apache-2.0 (add LICENSE-MIT and LICENSE-APACHE files before publishing).
