//! The interpreter. It runs statements and talks to the outside world only
//! through the `Host` trait, so the same engine can sit behind a terminal,
//! a test harness, or (later) a GUI toolkit.

use std::collections::HashMap;

use crate::ast::{BinOp, Expr, Placement, Stmt};
use crate::error::XtError;
use crate::parser::parse_line;

/// What the engine needs from whatever is hosting it.
pub trait Host {
    /// A script wrote to the message box, for example `put "Hi"`.
    fn message(&mut self, text: &str);
}

pub struct Interpreter {
    /// Variable names are case-insensitive (spec LEX-2), so keys are lowercase.
    vars: HashMap<String, String>,
}

impl Default for Interpreter {
    fn default() -> Self {
        Self::new()
    }
}

impl Interpreter {
    pub fn new() -> Self {
        Interpreter {
            vars: HashMap::new(),
        }
    }

    /// Parse and run one line of script.
    pub fn run_line(&mut self, src: &str, host: &mut dyn Host) -> Result<(), XtError> {
        if let Some(stmt) = parse_line(src)? {
            self.exec(&stmt, host)?;
        }
        Ok(())
    }

    /// All variables, sorted by name, for the prompt's `:vars` command.
    pub fn variables(&self) -> Vec<(String, String)> {
        let mut list: Vec<(String, String)> = self
            .vars
            .iter()
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect();
        list.sort();
        list
    }

    fn exec(&mut self, stmt: &Stmt, host: &mut dyn Host) -> Result<(), XtError> {
        match stmt {
            Stmt::Eval(expr) => {
                let v = self.eval(expr)?;
                host.message(&v);
            }
            Stmt::Get(expr) => {
                let v = self.eval(expr)?;
                self.set_var("it", v);
            }
            Stmt::Put { value, target } => {
                let v = self.eval(value)?;
                match target {
                    // `put v` with no destination writes to the message box (spec VAR-3).
                    None => host.message(&v),
                    Some((Placement::Into, name)) => self.set_var(name, v),
                    Some((Placement::Before, name)) => {
                        let old = self.stored(name);
                        self.set_var(name, format!("{v}{old}"));
                    }
                    Some((Placement::After, name)) => {
                        let old = self.stored(name);
                        self.set_var(name, format!("{old}{v}"));
                    }
                }
            }
        }
        Ok(())
    }

    fn set_var(&mut self, name: &str, value: String) {
        self.vars.insert(name.to_lowercase(), value);
    }

    /// The stored value of a variable, or empty if it was never assigned.
    fn stored(&self, name: &str) -> String {
        self.vars.get(&name.to_lowercase()).cloned().unwrap_or_default()
    }

    /// Constants first, then variables. A name that is neither evaluates to
    /// itself, as in classic HyperTalk (spec VAL-8 is still open).
    fn lookup(&self, name: &str) -> String {
        if let Some(c) = constant(name) {
            return c;
        }
        match self.vars.get(&name.to_lowercase()) {
            Some(v) => v.clone(),
            None => name.to_string(),
        }
    }

    fn eval(&self, expr: &Expr) -> Result<String, XtError> {
        match expr {
            Expr::Literal(s) => Ok(s.clone()),
            Expr::Var(name) => Ok(self.lookup(name)),
            Expr::Neg(inner) => {
                let n = to_number(&self.eval(inner)?)?;
                Ok(format_number(-n))
            }
            Expr::Binary { op, left, right } => {
                let l = self.eval(left)?;
                let r = self.eval(right)?;
                match op {
                    BinOp::Concat => Ok(format!("{l}{r}")),
                    BinOp::ConcatSpace => Ok(format!("{l} {r}")),
                    _ => arithmetic(*op, &l, &r),
                }
            }
        }
    }
}

fn constant(name: &str) -> Option<String> {
    let value = match name.to_lowercase().as_str() {
        "empty" => String::new(),
        "space" => " ".to_string(),
        "tab" => "\t".to_string(),
        "return" | "linefeed" => "\n".to_string(),
        "quote" => "\"".to_string(),
        "comma" => ",".to_string(),
        "colon" => ":".to_string(),
        "true" => "true".to_string(),
        "false" => "false".to_string(),
        "pi" => format_number(std::f64::consts::PI),
        _ => return None,
    };
    Some(value)
}

/// A string is numeric if it parses as a finite number (spec VAL-2).
fn to_number(s: &str) -> Result<f64, XtError> {
    match s.trim().parse::<f64>() {
        Ok(n) if n.is_finite() => Ok(n),
        _ => Err(XtError::new(format!("Expected a number but found \"{s}\""))),
    }
}

fn arithmetic(op: BinOp, l: &str, r: &str) -> Result<String, XtError> {
    let a = to_number(l)?;
    let b = to_number(r)?;
    let result = match op {
        BinOp::Add => a + b,
        BinOp::Sub => a - b,
        BinOp::Mul => a * b,
        BinOp::Div | BinOp::IntDiv | BinOp::Mod if b == 0.0 => {
            return Err(XtError::new("Can't divide by zero"));
        }
        BinOp::Div => a / b,
        BinOp::IntDiv => (a / b).trunc(),
        BinOp::Mod => a % b,
        BinOp::Concat | BinOp::ConcatSpace => {
            return Err(XtError::new("Internal error: concatenation is not arithmetic"));
        }
    };
    Ok(format_number(result))
}

/// Turn a number into text. Whole numbers print without a decimal point;
/// everything else prints with up to ten decimal places and trailing zeros
/// removed. The exact rule is still open (spec VAL-5, open question 6).
pub fn format_number(n: f64) -> String {
    if n == n.trunc() && n.abs() < 1e15 {
        return format!("{}", n as i64);
    }
    let s = format!("{n:.10}");
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    struct Capture(Vec<String>);

    impl Host for Capture {
        fn message(&mut self, text: &str) {
            self.0.push(text.to_string());
        }
    }

    fn run(lines: &[&str]) -> Vec<String> {
        let mut interp = Interpreter::new();
        let mut host = Capture(Vec::new());
        for line in lines {
            interp.run_line(line, &mut host).expect("script should run");
        }
        host.0
    }

    fn run_err(line: &str) -> XtError {
        let mut interp = Interpreter::new();
        let mut host = Capture(Vec::new());
        interp
            .run_line(line, &mut host)
            .expect_err("script should fail")
    }

    #[test]
    fn hello_world() {
        assert_eq!(run(&["put \"Hello World\""]), vec!["Hello World"]);
    }

    #[test]
    fn concatenation() {
        assert_eq!(run(&["put \"a\" & \"b\""]), vec!["ab"]);
        assert_eq!(run(&["put \"a\" && \"b\""]), vec!["a b"]);
    }

    #[test]
    fn precedence_and_parentheses() {
        assert_eq!(run(&["put 2 + 3 * 4"]), vec!["14"]);
        assert_eq!(run(&["put (2 + 3) * 4"]), vec!["20"]);
        assert_eq!(run(&["put -5 + 2"]), vec!["-3"]);
        assert_eq!(run(&["put 2 - -3"]), vec!["5"]);
    }

    #[test]
    fn variables_are_case_insensitive() {
        let out = run(&["PUT \"Hi\" INTO Greeting", "put greeting"]);
        assert_eq!(out, vec!["Hi"]);
    }

    #[test]
    fn unset_variable_evaluates_to_its_name() {
        assert_eq!(run(&["put banana"]), vec!["banana"]);
    }

    #[test]
    fn before_and_after() {
        let out = run(&["put \"b\" into x", "put \"a\" before x", "put \"c\" after x", "put x"]);
        assert_eq!(out, vec!["abc"]);
    }

    #[test]
    fn get_sets_it() {
        assert_eq!(run(&["get 2 * 21", "put it"]), vec!["42"]);
    }

    #[test]
    fn number_formatting() {
        assert_eq!(run(&["put 10 / 4"]), vec!["2.5"]);
        assert_eq!(run(&["put 1 / 3"]), vec!["0.3333333333"]);
        assert_eq!(run(&["put 7 div 2"]), vec!["3"]);
        assert_eq!(run(&["put 7 mod 2"]), vec!["1"]);
    }

    #[test]
    fn no_reserved_words() {
        assert_eq!(run(&["put 3 into put", "put put"]), vec!["3"]);
    }

    #[test]
    fn comments_and_blank_lines_do_nothing() {
        assert_eq!(run(&["", "-- just a comment", "put \"x\" -- trailing"]), vec!["x"]);
    }

    #[test]
    fn runtime_errors() {
        assert_eq!(run_err("put 1 / 0").message, "Can't divide by zero");
        assert!(run_err("put \"abc\" + 1").message.contains("Expected a number"));
    }

    #[test]
    fn syntax_errors_report_a_column() {
        assert_eq!(run_err("put").col, Some(3));
        assert_eq!(run_err("put \"a\" into").col, Some(12));
        let err = run_err("put \"oops");
        assert_eq!(err.col, Some(4));
        assert!(err.message.contains("closing quote"));
    }
}
