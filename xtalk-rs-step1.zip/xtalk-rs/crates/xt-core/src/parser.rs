//! A hand-written recursive-descent parser for one line of script.
//!
//! Binary operators are handled by one function driven by the LEVELS table,
//! tightest binding last (spec section 6).

use crate::ast::{BinOp, Expr, Placement, Stmt};
use crate::error::XtError;
use crate::lexer::{lex, Token, TokenKind};

/// Parse one line. Returns `None` for a blank or comment-only line.
pub fn parse_line(src: &str) -> Result<Option<Stmt>, XtError> {
    let tokens = lex(src)?;
    if tokens.is_empty() {
        return Ok(None);
    }
    let mut parser = Parser {
        tokens,
        pos: 0,
        end_col: src.chars().count(),
    };
    let stmt = parser.parse_statement()?;
    parser.expect_end()?;
    Ok(Some(stmt))
}

/// Operators from loosest to tightest binding. Word operators such as `div`
/// are only recognized in operator position (spec CTX-5).
const LEVELS: &[&[(&str, BinOp)]] = &[
    &[("&&", BinOp::ConcatSpace), ("&", BinOp::Concat)],
    &[("+", BinOp::Add), ("-", BinOp::Sub)],
    &[
        ("*", BinOp::Mul),
        ("/", BinOp::Div),
        ("div", BinOp::IntDiv),
        ("mod", BinOp::Mod),
    ],
];

struct Parser {
    tokens: Vec<Token>,
    pos: usize,
    /// Column just past the end of the line, for "expected something here" errors.
    end_col: usize,
}

impl Parser {
    fn peek(&self) -> Option<&Token> {
        self.tokens.get(self.pos)
    }

    /// Column of the current token, or the end of the line.
    fn here(&self) -> usize {
        self.peek().map_or(self.end_col, |t| t.col)
    }

    fn is_word(&self, word: &str) -> bool {
        matches!(
            self.peek(),
            Some(Token { kind: TokenKind::Word(w), .. }) if w.eq_ignore_ascii_case(word)
        )
    }

    fn is_op(&self, op: &str) -> bool {
        matches!(
            self.peek(),
            Some(Token { kind: TokenKind::Op(o), .. }) if o == op
        )
    }

    fn expect_end(&self) -> Result<(), XtError> {
        match self.peek() {
            None => Ok(()),
            Some(tok) => Err(XtError::at(
                tok.col,
                format!("Unexpected {} here", describe(&tok.kind)),
            )),
        }
    }

    fn parse_statement(&mut self) -> Result<Stmt, XtError> {
        if self.is_word("put") {
            self.pos += 1;
            let value = self.parse_expr()?;
            let target = self.parse_put_target()?;
            Ok(Stmt::Put { value, target })
        } else if self.is_word("get") {
            self.pos += 1;
            Ok(Stmt::Get(self.parse_expr()?))
        } else {
            // Not a command we know, so treat the line as an expression.
            Ok(Stmt::Eval(self.parse_expr()?))
        }
    }

    fn parse_put_target(&mut self) -> Result<Option<(Placement, String)>, XtError> {
        let placement = if self.is_word("into") {
            Placement::Into
        } else if self.is_word("before") {
            Placement::Before
        } else if self.is_word("after") {
            Placement::After
        } else {
            return Ok(None);
        };
        self.pos += 1;

        match self.peek().cloned() {
            Some(Token {
                kind: TokenKind::Word(name),
                ..
            }) => {
                self.pos += 1;
                Ok(Some((placement, name)))
            }
            _ => Err(XtError::at(self.here(), "Expected a variable name here")),
        }
    }

    fn parse_expr(&mut self) -> Result<Expr, XtError> {
        self.parse_binary(0)
    }

    /// If the current token is an operator at this level, say which one.
    fn binary_op_at(&self, level: usize) -> Option<BinOp> {
        let text = match &self.peek()?.kind {
            TokenKind::Op(o) => o.as_str(),
            TokenKind::Word(w) => w.as_str(),
            _ => return None,
        };
        LEVELS[level]
            .iter()
            .find(|entry| text.eq_ignore_ascii_case(entry.0))
            .map(|entry| entry.1)
    }

    fn parse_binary(&mut self, level: usize) -> Result<Expr, XtError> {
        if level == LEVELS.len() {
            return self.parse_unary();
        }
        let mut left = self.parse_binary(level + 1)?;
        while let Some(op) = self.binary_op_at(level) {
            self.pos += 1;
            let right = self.parse_binary(level + 1)?;
            left = Expr::Binary {
                op,
                left: Box::new(left),
                right: Box::new(right),
            };
        }
        Ok(left)
    }

    fn parse_unary(&mut self) -> Result<Expr, XtError> {
        if self.is_op("-") {
            self.pos += 1;
            Ok(Expr::Neg(Box::new(self.parse_unary()?)))
        } else {
            self.parse_primary()
        }
    }

    fn parse_primary(&mut self) -> Result<Expr, XtError> {
        let tok = match self.peek().cloned() {
            Some(t) => t,
            None => return Err(XtError::at(self.end_col, "Expected a value here")),
        };
        match tok.kind {
            TokenKind::Str(s) => {
                self.pos += 1;
                Ok(Expr::Literal(s))
            }
            TokenKind::Number(n) => {
                self.pos += 1;
                Ok(Expr::Literal(n))
            }
            TokenKind::Word(w) => {
                self.pos += 1;
                Ok(Expr::Var(w))
            }
            TokenKind::Op(o) if o == "(" => {
                self.pos += 1;
                let inner = self.parse_expr()?;
                if self.is_op(")") {
                    self.pos += 1;
                    Ok(inner)
                } else {
                    Err(XtError::at(self.here(), "Expected a closing parenthesis here"))
                }
            }
            TokenKind::Op(_) => Err(XtError::at(tok.col, "Expected a value here")),
        }
    }
}

fn describe(kind: &TokenKind) -> String {
    match kind {
        TokenKind::Number(n) => format!("number {n}"),
        TokenKind::Str(s) => format!("string \"{s}\""),
        TokenKind::Word(w) => format!("word '{w}'"),
        TokenKind::Op(o) => format!("'{o}'"),
    }
}
