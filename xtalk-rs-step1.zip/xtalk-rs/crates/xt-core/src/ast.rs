//! The syntax tree: what the parser produces and the interpreter runs.

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BinOp {
    Concat,      // &
    ConcatSpace, // &&
    Add,
    Sub,
    Mul,
    Div,
    IntDiv, // div
    Mod,    // mod
}

#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    /// A string or number literal, as text.
    Literal(String),
    /// A variable or constant name, in its original spelling.
    Var(String),
    Neg(Box<Expr>),
    Binary {
        op: BinOp,
        left: Box<Expr>,
        right: Box<Expr>,
    },
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Placement {
    Into,
    Before,
    After,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Stmt {
    /// `put <expr> [into|before|after <variable>]`
    Put {
        value: Expr,
        target: Option<(Placement, String)>,
    },
    /// `get <expr>` stores the value in `it`.
    Get(Expr),
    /// A bare expression typed at the prompt: evaluate it and show the result.
    Eval(Expr),
}
