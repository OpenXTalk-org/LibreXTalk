use std::fmt;

/// An error found while lexing, parsing, or running one line of script.
#[derive(Debug, Clone, PartialEq)]
pub struct XtError {
    pub message: String,
    /// Column in the source line (counting from 0) where the problem was
    /// found, if known.
    pub col: Option<usize>,
}

impl XtError {
    pub fn new(message: impl Into<String>) -> Self {
        XtError {
            message: message.into(),
            col: None,
        }
    }

    pub fn at(col: usize, message: impl Into<String>) -> Self {
        XtError {
            message: message.into(),
            col: Some(col),
        }
    }
}

impl fmt::Display for XtError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.message)
    }
}

impl std::error::Error for XtError {}
