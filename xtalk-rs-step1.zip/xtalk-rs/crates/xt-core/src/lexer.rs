//! Turns one line of script text into tokens.
//!
//! There are no keyword tokens. Every identifier is a `Word`, because xTalk
//! has no reserved words (spec LEX-4). The parser decides what a word means.

use crate::error::XtError;

#[derive(Debug, Clone, PartialEq)]
pub enum TokenKind {
    /// A number as written, such as `3.10`. Values are strings (spec VAL-1),
    /// so we keep the original text.
    Number(String),
    /// A string literal without its quotes.
    Str(String),
    /// An identifier, in its original spelling.
    Word(String),
    /// Punctuation or a symbol operator: + - * / & && ( ) ,
    Op(String),
}

#[derive(Debug, Clone, PartialEq)]
pub struct Token {
    pub kind: TokenKind,
    /// Column of the first character, counting from 0.
    pub col: usize,
}

fn op(text: &str, col: usize) -> Token {
    Token {
        kind: TokenKind::Op(text.to_string()),
        col,
    }
}

pub fn lex(src: &str) -> Result<Vec<Token>, XtError> {
    let chars: Vec<char> = src.chars().collect();
    let mut tokens = Vec::new();
    let mut i = 0;

    while i < chars.len() {
        let c = chars[i];
        let start = i;
        let next = chars.get(i + 1).copied();

        if c.is_whitespace() {
            i += 1;
        } else if (c == '-' && next == Some('-')) || c == '#' {
            // A comment runs to the end of the line (spec LEX-7).
            break;
        } else if c.is_ascii_digit() || (c == '.' && next.is_some_and(|d| d.is_ascii_digit())) {
            let mut seen_dot = false;
            while i < chars.len() && (chars[i].is_ascii_digit() || (chars[i] == '.' && !seen_dot)) {
                if chars[i] == '.' {
                    seen_dot = true;
                }
                i += 1;
            }
            tokens.push(Token {
                kind: TokenKind::Number(chars[start..i].iter().collect()),
                col: start,
            });
        } else if c == '"' {
            i += 1;
            let body_start = i;
            while i < chars.len() && chars[i] != '"' {
                i += 1;
            }
            if i >= chars.len() {
                return Err(XtError::at(start, "Missing closing quote for this string"));
            }
            tokens.push(Token {
                kind: TokenKind::Str(chars[body_start..i].iter().collect()),
                col: start,
            });
            i += 1; // skip the closing quote
        } else if c.is_alphabetic() || c == '_' {
            while i < chars.len() && (chars[i].is_alphanumeric() || chars[i] == '_') {
                i += 1;
            }
            tokens.push(Token {
                kind: TokenKind::Word(chars[start..i].iter().collect()),
                col: start,
            });
        } else if c == '&' && next == Some('&') {
            tokens.push(op("&&", start));
            i += 2;
        } else if "+-*/&(),".contains(c) {
            tokens.push(op(&c.to_string(), start));
            i += 1;
        } else {
            return Err(XtError::at(start, format!("Unexpected character '{c}'")));
        }
    }

    Ok(tokens)
}
