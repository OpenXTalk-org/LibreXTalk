//! xt-core: the headless xTalk engine.
//!
//! It knows nothing about windows, terminals, or files. Anything the script
//! shows to the user goes through the [`Host`] trait.

mod ast;
mod error;
mod interp;
mod lexer;
mod parser;

pub use ast::{BinOp, Expr, Placement, Stmt};
pub use error::XtError;
pub use interp::{format_number, Host, Interpreter};
pub use parser::parse_line;
