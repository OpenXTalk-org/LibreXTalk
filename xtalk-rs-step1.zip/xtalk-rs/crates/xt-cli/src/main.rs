//! `xt`: a command prompt for the xTalk engine.

use std::io::{self, BufRead, Write};

use xt_core::{parse_line, Host, Interpreter, XtError};

/// The host for a terminal: the message box is standard output.
struct StdoutHost;

impl Host for StdoutHost {
    fn message(&mut self, text: &str) {
        println!("{text}");
    }
}

fn print_help() {
    println!("Try these:");
    println!("  put \"Hello World\"");
    println!("  put 2 + 3 * 4");
    println!("  put \"Hello\" && \"World\" into greeting");
    println!("  put greeting");
    println!("  get 6 * 7");
    println!("  put it");
    println!();
    println!("Prompt commands:");
    println!("  :vars        show all variables");
    println!("  :ast <line>  show how a line is parsed");
    println!("  :help        show this help");
    println!("  :quit        leave (Ctrl-D works too)");
}

fn report_error(source: &str, err: &XtError) {
    if let Some(col) = err.col {
        eprintln!("  {source}");
        eprintln!("  {}^", " ".repeat(col));
    }
    eprintln!("Error: {err}");
}

fn main() {
    println!("xt 0.0.1. Type :help for help, :quit to leave.");

    let mut interp = Interpreter::new();
    let mut host = StdoutHost;
    let stdin = io::stdin();
    let mut line = String::new();

    loop {
        print!("> ");
        io::stdout().flush().ok();

        line.clear();
        match stdin.lock().read_line(&mut line) {
            Ok(0) => {
                println!();
                break; // end of input (Ctrl-D)
            }
            Ok(_) => {}
            Err(e) => {
                eprintln!("Could not read input: {e}");
                break;
            }
        }
        let input = line.trim_end();

        if let Some(rest) = input.trim().strip_prefix(":ast ") {
            match parse_line(rest) {
                Ok(Some(stmt)) => println!("{stmt:#?}"),
                Ok(None) => println!("(nothing to parse)"),
                Err(e) => report_error(rest, &e),
            }
            continue;
        }

        match input.trim() {
            ":quit" | ":q" => break,
            ":help" => {
                print_help();
                continue;
            }
            ":vars" => {
                for (name, value) in interp.variables() {
                    println!("{name} = {value}");
                }
                continue;
            }
            _ => {}
        }

        if let Err(err) = interp.run_line(input, &mut host) {
            report_error(input, &err);
        }
    }
}
